public interface Input {
    String requestInput();
}
